package ex_03;

public interface Identifiable {
	String getId();
}
