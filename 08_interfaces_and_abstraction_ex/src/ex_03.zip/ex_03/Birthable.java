package ex_03;

public interface Birthable {
	String getBirthDate();
}
