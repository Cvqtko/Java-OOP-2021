package ex_01;

public interface Person {
	String getName();
	int getAge();
}
