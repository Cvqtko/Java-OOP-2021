package ex_06.interfaces;

public interface Mission {

    void completeMission();

    String getCodeName();

    String getState();
}