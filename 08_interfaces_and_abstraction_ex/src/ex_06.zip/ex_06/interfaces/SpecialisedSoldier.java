package ex_06.interfaces;

public interface SpecialisedSoldier {

    String getCorps();
}