package ex_06.interfaces;

public interface LieutenantGeneral {

    void addPrivate(Private soldier);
}