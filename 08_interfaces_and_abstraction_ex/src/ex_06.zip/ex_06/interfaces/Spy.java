package ex_06.interfaces;

public interface Spy {

    String getCodeNumber();
}