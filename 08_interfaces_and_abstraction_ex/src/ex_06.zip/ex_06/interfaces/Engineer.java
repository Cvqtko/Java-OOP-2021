package ex_06.interfaces;

import java.util.List;

public interface Engineer {

    void addRepair(Repair repair);

    List<Repair> getRepairs();

}