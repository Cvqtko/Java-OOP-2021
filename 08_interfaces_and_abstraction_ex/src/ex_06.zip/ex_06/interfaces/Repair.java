package ex_06.interfaces;


public interface Repair {
    String getName();

    int getHoursWorked();
}