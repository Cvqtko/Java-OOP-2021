package ex_06.interfaces;

public interface Private extends Soldier {

    double getsSalary();
}