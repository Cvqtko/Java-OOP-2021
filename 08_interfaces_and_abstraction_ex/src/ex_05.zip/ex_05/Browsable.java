package ex_05;

public interface Browsable {
    String browse();
}