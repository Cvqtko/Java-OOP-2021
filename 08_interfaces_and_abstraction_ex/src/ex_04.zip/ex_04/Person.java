package ex_04;

public interface Person {
    String getName();
    int getAge();
}