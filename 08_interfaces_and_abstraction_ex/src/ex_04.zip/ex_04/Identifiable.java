package ex_04;

public interface Identifiable {
	String getId();
}
