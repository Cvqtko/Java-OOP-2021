package ex_04;

public interface Buyer {
    void buyFood();
    int getFood();
}