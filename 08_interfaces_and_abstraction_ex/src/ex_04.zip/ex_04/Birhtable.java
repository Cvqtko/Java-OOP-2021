package ex_04;

public interface Birhtable {
    String getBirthDate();
}